<?php
require_once("../connect_db.php");
require_once("../config.php");
session_start();
if(isset($_SESSION['login'])){
    header("Location: ".INDEX_URL."main/index.php");
    exit();
}
else
    $error='';
if($_SERVER["REQUEST_METHOD"]=="POST"){
    if(isset($_POST["username"])&&isset($_POST["password"])){
        $user=trim($_POST["username"]);
        $pass=trim($_POST["password"]);
        if(!empty($user)&&!empty($pass)){
            $conn=connect_db();
            if($conn){
                $sql="SELECT * from users where username=? and pass=?";
                $stmt=$conn->prepare($sql);
                if($stmt){
                    $password=md5($pass);
                    $stmt->bind_param("ss",$user,$password);
                    $stmt->execute();
                    $result=$stmt->get_result();
                    if($result&& $result->num_rows>0){
                        $_SESSION['login']=$user;
                        header("Location: ".INDEX_URL."main/index.php");
                        exit();
                    }
                    else
                    $error="loi";
                    $stmt->close();
                } else $error="sai pass hoặc tên đăng nhập rồi";
                $conn->close();
            } else $error="loi ket noi";
        }
        else $error="mày đùa bố mày à";
    }
    else $error="chịu chịu chịu";
}
?>


<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login - Gaming Bright</title>
    <link rel="stylesheet" href="style-user.css">
    <link rel="stylesheet" href="style2.css">
    </head>
<body>
    <div class="chose">
        <a class="ad"href="../login/admin.php">ADMIN</a>
        <a class="us"href="../login/user.php">USER</a>
    </div>
    <div class="background-container">
        <img src="nen.png" alt="Gaming Bright Background" class="background-image">
        </div>

    <div class="login-container">
        <div class="login-box">
            <h1 class="user-title">USER LOGIN</h1>
            <div class="logo">
                <img src="image.png" alt="Logo" style="height: 45px;"> 
            </div>

            <form action="user.php" method="post">
                <div class="input-group">
                    <input type="text" name="username" id="username" placeholder=" " required>
                    <label for="username">USERNAME</label>
                </div>

                <div class="input-group">
                    <input type="password" name="password" placeholder=" " required>
                    <label for="password">PASSWORD</label>
                </div>
                <?php if (!empty($error)): ?>
                <div class="error-msg">
                    <?php
                    echo htmlspecialchars($error);
                    ?>
                </div><?php endif; ?>
                <button type="submit" class="login-btn">ĐĂNG NHẬP</button>
            </form>

            <div class="footer-links">
                <a href="#" class="forgot-link">Quên mật khẩu?</a>
                <a href="../logon/user.php" class="register-link">Đăng ký tài khoản mới</a>
            </div>
        </div>
    </div>
</body>
</html>