<?php
    session_start();
    require_once("../config.php");
    require_once("../connect_db.php");
    
    //Nếu đã đăng nhập, chuyển hướng đến trang admin
    if (isset($_SESSION['admin_login'])) {
        header("Location: " . INDEX_URL . "admin/main/index.php");
        exit();
     }

    $error = '';
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST["username"]) && isset($_POST["password"])) {
            $username = trim($_POST["username"]);
            $password = trim($_POST["password"]);

            if (!empty($username) && !empty($password)) {
                $conn = connect_db();
               
                if ($conn) {
                    $sql = "SELECT * FROM admin WHERE TKadmin = ? AND PASS = ?";
                    $stmt = $conn->prepare($sql);
                    
                    if ($stmt) {
                        $pass = md5($password);
                        $stmt->bind_param("ss", $username, $pass);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result && $result->num_rows > 0) {
                            $_SESSION['admin_login'] = $username;
                            header("Location: " . INDEX_URL . "main/index.php");
                            exit();
                        }
                         else{
                           $error = "Tên đăng nhập hoặc mật khẩu không đúng.";
                        }
                        $stmt->close();
                    } else {
                        $error = "Lỗi truy vấn cơ sở dữ liệu.";
                    }
                    $conn->close();
                } else {
                    $error = "Không thể kết nối cơ sở dữ liệu.";
                }
            } else {
                $error = "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.";
            }
        } else {
            $error = "Vui lòng nhập đầy đủ thông tin.";
        }
    }
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - ROG Style</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="background-container">
        <img src="nen.png" class="background-image">
    </div>

    <div class="login-container">
        <div class="login-box">
            <h1 class="admin-title">ADMIN LOGIN</h1>
        
            <div class="logo">
                <svg width="40" height="40" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M50 0L80 40H60L50 10L40 40H20L50 0Z" fill="#1ABC9C"/>
                    <path d="M50 100L20 60H40L50 90L60 60H80L50 100Z" fill="#E74C3C"/>
                </svg>
            </div>
            
            

            <form method="POST" action="/do_an/login/admin.php">
                <div class="input-group">
                    <input type="text" id="username" name="username" placeholder=" " value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
                    <label for="username">USERNAME</label>
                </div>

                <div class="input-group">
                    <input type="password" id="password" name="password" placeholder=" " required>
                    <label for="password">PASSWORD</label>
                </div>
                <?php if (!empty($error)): ?>
                <div class="error-message">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
                <button type="submit" class="login-btn">LOGIN</button>
            </form>
                <a href="../start/index.html" class="back-link">Back to Website</a>
            </div>
        </div>
    </div>
</body>
</html>