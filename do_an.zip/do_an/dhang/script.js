function chuyen(){
    window.location.href = "../main/index.php";
}