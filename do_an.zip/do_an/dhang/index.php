<?php
session_start();
require_once("../connect_db.php");
require_once("../config.php");

if (!isset($_SESSION['login'])) {
    header("Location: " . INDEX_URL . "login/user.php");
    exit();
}

$conn = connect_db();
$user = $_SESSION['login'];

// Lấy MaKH
$sql = "SELECT MaKH FROM users WHERE username='$user'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $MaKH = $row['MaKH'];
} else {
    die("Không tìm thấy khách hàng!");
}

// Xử lý hủy đơn hàng
if (isset($_GET['huy'])) {
    $MaDH = $_GET['huy'];
    $sql_update = "UPDATE donhang SET TrangThai='Huy' WHERE MaDH='$MaDH' AND MaKH='$MaKH'";
    $conn->query($sql_update);
    header("Location: " . INDEX_URL . "dhang/index.php");
    exit();
}

// Xóa đơn hàng
if (isset($_GET['delete'])) {
    $MaDH = $_GET['delete'];
    $sql_delete = "DELETE FROM donhang WHERE MaDH='$MaDH' AND MaKH='$MaKH'";
    $conn->query($sql_delete);
    header("Location: " . INDEX_URL . "dhang/index.php");
    exit();
}

// Lấy danh sách đơn hàng
$sql = "SELECT * FROM donhang WHERE MaKH='$MaKH'";
$sanpham = [];
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sanpham[] = $row;
    }
}



?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quản lý đơn hàng</title>
<style>
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #aaa; padding: 8px; text-align: center; }
    .btn { padding: 5px 10px; cursor: pointer; }
</style>
</head>
<body>

<h1>Quản Lý Đơn Hàng</h1>
<button onclick="chuyen()"><p class="ktp">+</p>Thêm Đơn Hàng Mới</button>

<div class="content">
    <table>
        <tr class="tr_head">
            <th>Mã ĐH</th>
            <th>Ngày Đặt</th>
            <th>Trạng Thái</th>
            <th>Tổng Tiền</th>
            <th>Hành Động</th>
        </tr>

        <?php if(!empty($sanpham)): ?>
            <?php foreach($sanpham as $dh): ?>
                <tr>
                    <td><?= htmlspecialchars($dh['MaDH']); ?></td>
                    <td><?= htmlspecialchars($dh['NgayDat']); ?></td>
                    <td><?= htmlspecialchars($dh['TrangThai']); ?></td>
                    <td><?= number_format($dh['TongTien'],0,',','.'); ?> ₫</td>
                    <td>
    <?php 
        $tt = $dh['TrangThai'];

        // Cho xac nhan → Edit + Hủy + Xóa
        if ($tt === 'Cho xac nhan'): ?>

            <!-- Edit -->
            <form action="../edit/index.php" method="post" style="display:inline">
                <input type="hidden" name="MaDH" value="<?= htmlspecialchars($dh['MaDH']); ?>">
                <button type="submit" class="btn">📝</button>
            </form>

            <!-- Hủy -->
            <a href="?huy=<?= htmlspecialchars($dh['MaDH']); ?>" 
               onclick="return confirm('Bạn có chắc muốn hủy đơn hàng này không?')" 
               class="btn">HỦY</a>

            <!-- Xóa -->
            <a href="?delete=<?= htmlspecialchars($dh['MaDH']); ?>" 
               onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này không?')" 
               class="btn">❌</a>

        <?php 
        // Da giao hoặc Huy → Chỉ Xóa
        elseif ($tt === 'Da Giao' || $tt === 'huy'): ?>

            <a href="?delete=<?= htmlspecialchars($dh['MaDH']); ?>" 
               onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này không?')" 
               class="btn">❌</a>

        <?php 
        // Dang giao → không hiện gì
        endif; 
    ?>
</td>

                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="5">Chưa có đơn hàng nào</td></tr>
        <?php endif; ?>

    </table>
</div>

<script>
function chuyen() {
    window.location.href = '../main/index.php';
}
</script>

</body>
</html>
    