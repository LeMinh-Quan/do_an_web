<?php
require_once("../connect_db.php");
require_once("../config.php");
session_start();
if(isset($_SESSION['user_logon'])){
  header("Location: ".INDEX_URL."login/user.php");
  exit();
}
$error="";
if($_SERVER["REQUEST_METHOD"]=="POST"){
  $username=isset($_POST["name"])?trim($_POST["name"]):"";
  $email=isset($_POST["email"])?trim($_POST["email"]):"";
  $pass=isset($_POST["password"])?trim($_POST["password"]):"";
  $confirm=isset($_POST["confirm"])?trim($_POST["confirm"]):"";

  if($username=="")
    echo"nhap username";
  else
    if($email=="")
      echo"nhap email";
    else
      if($pass!==$confirm)
        echo"pass khong khop";
      else



        {
          $conn=connect_db();

          if($conn){
            $password=md5($pass);
          $maKH="KH".rand(1,99999);
          $sql="insert into users (maKH, username, email, pass) values(?,?,?,?)";
          $stmt=$conn->prepare($sql);
          $stmt->bind_param("ssss",$maKH,$username,$email,$password);
        if($stmt->execute()){
          echo "";
        }
        else
          echo "Đăng ký thành công!";
header("Location: ../login/user.php");

          }
          $stmt->close();
        }
        
      $conn->close();
}
else
  echo"vui long nhap thong tin";
?>



<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Đăng ký tài khoản</title>
  <link rel="stylesheet" href="style.css">
  
</head>
<body>
  <div class="container">
    <h1>Đăng ký tài khoản</h1>
    <form action="user.php" method="post">
      <label for="name">Họ và tên</label>
      <input type="text" name="name" id="name" placeholder="Nhập họ tên" required>

      <label for="email">Email</label>
      <input type="email" name="email" id="email" placeholder="you@example.com" required>

      <label for="password">Mật khẩu</label>
      <input type="password" name="password" id="password" placeholder="Nhập mật khẩu" required>

      <label for="confirm">Xác nhận mật khẩu</label>
      <input type="password" name="confirm" id="confirm" placeholder="Nhập lại mật khẩu" required>

      <button class="btn" type="submit">Tạo tài khoản</button>
      <p>Đã có tài khoản? <a href="#">Đăng nhập</a></p>
    </form>
  </div>
</body>
</html>
