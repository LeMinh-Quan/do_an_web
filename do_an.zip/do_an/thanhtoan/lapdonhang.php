<?php
session_start();
require_once '../config.php';
require_once '../connect_db.php';
if(!isset($_SESSION['login'])){
    header("Location: ".INDEX_URL."login/user.php");
    exit();
}
$conn=connect_db();
$TenKH = $_SESSION['login'];
$sql_KH="SELECT MaKH from users where username ='$TenKH';";
$result=$conn->query($sql_KH);
if($result && $result->num_rows > 0){
    $MaKH = $result->fetch_assoc()['MaKH'];
} else {
    die("Người dùng không tồn tại!");
}

$MaSP    = $_POST['MaSP'] ?? '';
$date    = $_POST['date'] ?? '';
$Gia     = $_POST['Gia'] ?? '';
$SoLuong = $_POST['SoLuong'] ?? '';
$tongtien=$Gia*$SoLuong;
$MaDH="DH".rand(000,9999);
// 1. Thêm đơn hàng
$sql_add_dh = "INSERT INTO donhang (MaDH, MaKH, NgayDat, TongTien, TrangThai)
               VALUES ('$MaDH', '$MaKH', '$date', '$tongtien', 'Cho xac nhan')";

if(!$conn->query($sql_add_dh)){
    die("Lỗi thêm đơn hàng: " . $conn->error);
}

// 2. Thêm chi tiết đơn hàng
$sql_add_ct = "INSERT INTO ct_donhang (MaDH, MaSP, SoLuong, DonGia)
               VALUES ('$MaDH', '$MaSP', '$SoLuong', '$Gia')";

if(!$conn->query($sql_add_ct)){
    die("Lỗi thêm CT_DH: " . $conn->error);
}
// Sau khi tạo đơn hàng xong -> chuyển sang bước thanh toán
?>
<form id="next" action="../thanhtoan/index.php" method="post">
    <input type="hidden" name="MaDH" value="<?php echo $MaDH; ?>">
    <input type="hidden" name="MaSP" value="<?php echo $MaSP; ?>">
    <input type="hidden" name="TongTien" value="<?php echo $tongtien; ?>">
    <input type="hidden" name="Ngayvagio" value="<?php echo date('Y-m-d H:i:s'); ?>">
</form>

<script>
document.getElementById("next").submit();
</script>
<?php
exit();
?>