<?php
session_start();
require_once '../config.php';
require_once '../connect_db.php';

$conn = connect_db();

$MaTT = $_POST['MaTT'] ?? '';
$MaDH = $_POST['MaDH'] ?? '';
$PhuongThuc = $_POST['PhuongThuc'] ?? '';

if (!$MaTT || !$MaDH || !$PhuongThuc) {
    die("Thiếu thông tin thanh toán!");
}

// Trạng thái mặc định
$TrangThai = 'Chưa thanh toán';

// Cập nhật bảng thanhtoan
$stmt = $conn->prepare("UPDATE thanhtoan SET PhuongThuc=?, TrangThai=? WHERE MaTT=?");
$stmt->bind_param("sss", $PhuongThuc, $TrangThai, $MaTT);
if(!$stmt->execute()){
    die("Lỗi cập nhật thanh toán: " . $stmt->error);
}

// Nếu phương thức khác tiền mặt thì hiển thị QR code
if (strtolower($PhuongThuc) === "tien mat") {
    // Tiền mặt: thông báo hoàn tất đặt hàng
    echo "<h2>Đơn hàng của bạn đã được ghi nhận!</h2>";
    echo "<p>Hình thức thanh toán: Tiền mặt</p>";
    echo "<p>Trạng thái: Chưa thanh toán. Vui lòng thanh toán khi nhận hàng.</p>";
} else {
    if(strtolower($PhuongThuc) === "chuyen khoan"){
        echo "<h2>Quét QR để thanh toán $PhuongThuc</h2>";
    echo "<img src='../anh/maqr.png' alt='QR code' style='max-width:300px;'>";
    echo "<p>Vui lòng quét QR để thanh toán.</p>";
    }
    else{
        echo "loi thanh toan";
    }
    
}

echo "<br><a href='../main/index.php'>Quay về trang chủ</a>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <style>
body {
    font-family: Arial, sans-serif;
    background-color: #1e1e1e;
    color: #fff;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 30px;
    min-height: 100vh;
}

h2 {
    color: #4CAF50;
    margin-bottom: 20px;
    text-align: center;
}

p {
    font-size: 18px;
    margin: 10px 0;
    text-align: center;
}

img {
    max-width: 300px;
    width: 100%;
    height: auto;
    border-radius: 12px;
    margin: 20px 0;
    box-shadow: 0 0 15px rgba(0,255,0,0.5);
}

a {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #4CAF50;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    transition: 0.3s;
}

a:hover {
    background-color: #45a049;
    transform: scale(1.05);
}

.error {
    color: #ff4d4d;
    font-weight: bold;
    text-align: center;
    margin: 20px 0;
}
</style>
</body>
</html>