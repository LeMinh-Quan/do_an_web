<?php
session_start();
require_once '../config.php';
require_once '../connect_db.php';

if(!isset($_SESSION['login'])){
    header("Location: ".INDEX_URL."login/user.php");
    exit();
}

$conn = connect_db();

// Lấy dữ liệu từ POST
$MaDH      = $_POST['MaDH'] ?? '';
$MaSP      = $_POST['MaSP'] ?? '';
$Ngayvagio = $_POST['Ngayvagio'] ?? '';

// Kiểm tra dữ liệu đầu vào
if(empty($MaDH) || empty($MaSP)){
    die("Thiếu thông tin đơn hàng hoặc sản phẩm.");
}

// Kiểm tra xem đơn hàng có tồn tại không
$checkDH = $conn->prepare("SELECT * FROM donhang WHERE MaDH=?");
$checkDH->bind_param("s", $MaDH);
$checkDH->execute();
$resDH = $checkDH->get_result();
if($resDH->num_rows == 0){
    die("Đơn hàng $MaDH không tồn tại.");
}

// Lấy thông tin sản phẩm trong đơn hàng
$sql2 = "SELECT sp.STT, sp.TenSP, dh.NgayDat, ct.SoLuong, dh.TongTien
         FROM donhang dh
         JOIN ct_donhang ct ON ct.MaDH = dh.MaDH
         JOIN sanpham sp ON sp.MaSP = ct.MaSP
         WHERE sp.MaSP = ? AND dh.MaDH = ?";
$stmt = $conn->prepare($sql2);
$stmt->bind_param("ss", $MaSP, $MaDH);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows == 0){
    die("Không tìm thấy sản phẩm nào với MaSP = $MaSP trong đơn hàng $MaDH.");
}

$row = $result->fetch_assoc();
$STT   = $row['STT'];
$TenSP = $row['TenSP'];
$date  = $row['NgayDat'];
$SoL   = $row['SoLuong'];
$tong  = $row['TongTien'];

// Tạo mã thanh toán
$MaTT = "TT" . rand(100,9999);

// Thêm bản ghi thanh toán nếu chưa tồn tại
$checkTT = $conn->prepare("SELECT * FROM thanhtoan WHERE MaDH=?");
$checkTT->bind_param("s", $MaDH);
$checkTT->execute();
$resTT = $checkTT->get_result();
if($resTT->num_rows == 0){
    $insertTT = $conn->prepare("INSERT INTO thanhtoan (MaTT, MaDH, PhuongThuc, Ngayvagio, TrangThai)
                                VALUES (?, ?, '', ?, 'Chưa thanh toán')");
    $insertTT->bind_param("sss", $MaTT, $MaDH, $Ngayvagio);
    if(!$insertTT->execute()){
        die("Lỗi thêm bản ghi thanh toán: " . $insertTT->error);
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Thanh toán</title>
<style>
    body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 20px; }
    .container { max-width: 600px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    td, th { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
    input[type="submit"] { background: #4CAF50; color: #fff; border: none; padding: 10px 20px; cursor: pointer; border-radius: 4px; }
    input[type="submit"]:hover { background: #45a049; }
</style>
</head>
<body>
<div class="container">
    <h2>Thanh toán đơn hàng</h2>
    <form action="thanhtoan.php" method="post">
        <!-- Thông tin cần gửi -->
        <input type="hidden" name="MaTT" value="<?php echo $MaTT; ?>">
        <input type="hidden" name="MaDH" value="<?php echo $MaDH; ?>">

        <!-- Thông tin hiển thị -->
        <table>
            <tr>
                <th>Sản phẩm</th>
                <td><?php echo htmlspecialchars($TenSP); ?></td>
            </tr>
            <tr>
                <th>Số lượng</th>
                <td><?php echo htmlspecialchars($SoL); ?></td>
            </tr>
            <tr>
                <th>Ngày đặt</th>
                <td><?php echo htmlspecialchars($date); ?></td>
            </tr>
            <tr>
                <th>Tổng tiền</th>
                <td><?php echo number_format($tong,0,',','.'); ?> VNĐ</td>
            </tr>
            <tr>
                <th>Phương thức thanh toán</th>
                <td>
                    <select name="PhuongThuc" required>
                        <option value="Tien mat">Tiền mặt</option>
                        <option value="Chuyen khoan">MoMo</option>
                    </select>
                </td>
            </tr>
        </table>

        <input type="submit" value="Xác nhận thanh toán">
    </form>
</div>
</body>
</html>
