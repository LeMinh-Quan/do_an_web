<?php
session_start();
require_once '../config.php';
require_once '../connect_db.php';

if(!isset($_SESSION['login'])){
    header("Location: ".INDEX_URL."login/user.php");
    exit();
}

$conn = connect_db();
$username = $_SESSION['login'];

// Lấy MaKH và username
$stmt = $conn->prepare("SELECT maKH, username FROM users WHERE username=?");
if(!$stmt){
    die("Lỗi SQL: ".$conn->error);
}
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
if($result && $result->num_rows > 0){
    $user = $result->fetch_assoc();
    $MaKH = $user['maKH'];
    $HoTen = $user['username'];
} else {
    die("Không tìm thấy thông tin user!");
}

// Xử lý submit thêm địa chỉ
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['them_diachi'])){
    $ChiTietDiaChi = $_POST['ChiTietDiaChi'] ?? '';
    $PhuongXa      = $_POST['PhuongXa'] ?? '';
    $QuanHuyen     = $_POST['QuanHuyen'] ?? '';
    $ThanhPho      = $_POST['ThanhPho'] ?? '';
    $DiaChiGiaoHang= $_POST['DiaChiGiaoHang'] ?? '';
    $GhiChu        = $_POST['GhiChu'] ?? '';

    if($ChiTietDiaChi && $PhuongXa && $QuanHuyen && $ThanhPho && $DiaChiGiaoHang){
        $stmt2 = $conn->prepare("INSERT INTO diachi(MaKH, ChiTietDiaChi, PhuongXa, QuanHuyen, ThanhPho, DiaChiGiaoHang, GhiChu) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt2->bind_param("sssssss", $MaKH, $ChiTietDiaChi, $PhuongXa, $QuanHuyen, $ThanhPho, $DiaChiGiaoHang, $GhiChu);
        if($stmt2->execute()){
            header("Location: diachi.php");
            exit();
        } else {
            $error = "Lỗi thêm địa chỉ: " . $conn->error;
        }
    } else {
        $error = "Vui lòng điền đầy đủ thông tin!";
    }
}

// Lấy danh sách địa chỉ của user
$stmt3 = $conn->prepare("SELECT * FROM diachi WHERE MaKH=?");
$stmt3->bind_param("s", $MaKH);
$stmt3->execute();
$result3 = $stmt3->get_result();
$diachi = [];
if($result3 && $result3->num_rows > 0){
    while($row = $result3->fetch_assoc()){
        $diachi[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Địa chỉ giao hàng</title>
<style>
body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 20px; }
.container { max-width: 800px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; }
table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
td, th { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
h2, h3 { text-align: center; margin-bottom: 20px; }
form label { display: block; margin-bottom: 10px; }
form input, form select { width: 100%; padding: 8px; margin-top: 4px; }
input[type="submit"] { background: #4CAF50; color: #fff; border: none; padding: 10px 20px; cursor: pointer; border-radius: 4px; margin-top: 10px; }
input[type="submit"]:hover { background: #45a049; }
.error { color: red; text-align: center; margin-bottom: 15px; }
</style>
</head>
<body>
<div class="container">
    <h2>Địa chỉ giao hàng của <?php echo htmlspecialchars($HoTen); ?></h2>

    <?php if(isset($error)) echo '<p class="error">'.htmlspecialchars($error).'</p>'; ?>

    <?php if(count($diachi) > 0): ?>
    <table>
        <tr>
            <th>Địa chỉ</th>
            <th>Loại</th>
            <th>Ghi chú</th>
        </tr>
        <?php foreach($diachi as $d): ?>
        <tr>
            <td><?php echo htmlspecialchars($d['ChiTietDiaChi'].", ".$d['PhuongXa'].", ".$d['QuanHuyen'].", ".$d['ThanhPho']); ?></td>
            <td><?php echo htmlspecialchars($d['DiaChiGiaoHang']); ?></td>
            <td><?php echo htmlspecialchars($d['GhiChu']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php else: ?>
        <p>Chưa có địa chỉ nào được thêm!</p>
    <?php endif; ?>

    <h3>Thêm địa chỉ mới</h3>
    <form action="" method="post">
        <input type="hidden" name="them_diachi" value="1">
        <label>Chi tiết địa chỉ: <input type="text" name="ChiTietDiaChi" required></label>
        <label>Phường/Xã: <input type="text" name="PhuongXa" required></label>
        <label>Quận/Huyện: <input type="text" name="QuanHuyen" required></label>
        <label>Thành phố: <input type="text" name="ThanhPho" required></label>
        <label>Loại địa chỉ:
            <select name="DiaChiGiaoHang">
                <option value="Nha">Nhà</option>
                <option value="CongTy">Công ty</option>
            </select>
        </label>
        <label>Ghi chú: <input type="text" name="GhiChu"></label>
        <input type="submit" value="Thêm địa chỉ">
    </form>
</div>
</body>
</html>
