<?php 
DEFINE('INDEX_URL','http://localhost/do_an/');

DEFINE('DB_HOST','localhost');
DEFINE('DB_NAME','my_db');
DEFINE('DB_USERNAME','root');
DEFINE('DB_PASSWORD','');
?>