    <?php
    session_start();
    require_once '../connect_db.php';
    require_once '../config.php';
    $conn = connect_db();
    $cpu=$_POST['CPU']??'all'; 
    $ram=$_POST['RAM']??'all';
    $rom=$_POST['ROM']??'all';
    $gpu=$_POST['GPU']??'all';
    $hdh=$_POST['HDH']??'all';
    $R_GB=$_POST['R_GB']??'all';
    $sql = "SELECT *
    FROM sanpham
    JOIN mota ON sanpham.MaSP = mota.MaSP
    LEFT JOIN cpu ON mota.CPU = cpu.MaCPU
    LEFT JOIN ram ON mota.RAM = ram.MaRAM
    LEFT JOIN rom ON mota.ROM = rom.MaROM
    LEFT JOIN gpu ON mota.GPU = gpu.MaGPU
    LEFT JOIN hedieuhanh hdh ON mota.HeDieuHanh = hdh.MaHDH
    where 1=1";
    if($cpu!='all')
    {
        $sql.=" AND cpu.TenCPU like'%$cpu%'";
    }
    if($ram!='all'|| $R_GB!='all')
    {
        
            if($ram!='all'&& $R_GB!='all'){
                $sql.=" AND ram.LoaiRAM like'%$ram%'and  ram.DungLuong LIKE '%$R_GB%'";
            }
            else{
                if($ram!='all'|| $R_GB!='all')
                    $sql .= " AND (ram.LoaiRAM LIKE '%$ram%' or ram.DungLuong LIKE '%$R_GB%')";
                
            }
            
        

    }
    if($rom!='all')
    {
        $sql.=" AND rom.MaROM like'%$rom%'";
    }
    if ($gpu != 'all') {
        // G_TH hoặc G_R tùy bạn đặt trong DB
        if ($gpu == 'G_TH')
            $sql .= " AND gpu.LoaiGPU LIKE '%Tích hợp%'";
        else
            $sql .= " AND gpu.LoaiGPU LIKE '%Rời%'";
    }
    if ($hdh != 'all') {
        $sql .= " AND hdh.TenHDH LIKE '%$hdh%'";
    }

    $sql.=" LIMIT 0, 35";
    $sanpham = [];
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        
        while ($row = $result->fetch_assoc()) {
            $sanpham[] = $row;
        }
    }
    
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="header">
      <a class="name" href="../start/index.html">TQS_store</a></li>
      <nav>
        <form action="../search/index.php" method="post">
          <input type="search" placeholder="tìm kiếm sản phẩm" name="search" id="search"><button>🔍</button>
        </form>
        
      
        <a href="../dhang/index.php">🚚</a>
        
    <a href="../logout/index.php">🚪</a>
      </nav>
      </div>
      <div class="options">
      <form action="../loc/index.php" method="post">

        <label for="CPU">CPU: </label>
        <select name="CPU" id="">
          <option value="all">All</option>
          <option value="Apple">Apple</option>
          <option value="i5">Core i5</option>
          <option value="i7">Core i7</option>
          <option value="i9">Core i9</option>
          <option value="Ryzen">Ryzen</option>
        </select>
        <div class="ram">
          <label for="RAM">RAM: </label>
          <select name="RAM" id="RAM">
            <option value="all">All</option>
            <option value="DDR4">DDR4</option>
            <option value="DDR5">DDR5</option>
          </select>
          <select name="R_GB" id="R_GB">
            <option value="all">All</option>
            <option value="8GB">8GB</option>
            <option value="16GB">16GB</option>
            <option value="32GB">32GB</option>
          </select>
        </div>
        <div> <label for="ROM">ROM: </label>
          <select name="ROM" id="ROM">

            <option value="all">All</option>
            <option value="ROM01">256GB</option>
            <option value="ROM02">512GB</option>
            <option value="ROM03">1TB</option>
          </select>
        </div>
        <div><label for="GPU">GPU: </label>
          <select name="GPU" id="GPU">
            <option value="all">All</option>
            <option value="G_TH">Tích hợp</option>
            <option value="G_R">Rời</option>
          </select>
        </div>

        <label for="HDH">Hệ điều hành: </label>
        <select name="HDH" id="HDH">
          <option value="all">All</option>
          <option value="Win11">Windows 11</option>
          <option value="MacOS">MacOS</option>
        </select>
        <input type="reset" value="Làm mới">
        <input type="submit" value="Lọc">

      </form>
    </div>
        <?php 
        if($ram!='DDR 4'&& $R_GB!='32GB'){
            $a=0;
        for($i=0; $i<count($sanpham); $i++){
            for ($i = 0; $i < count($sanpham); $i++) {
        list($Ten, $Loai, $TH, $MT,$MaSP, $Gia, $SL) = [
            htmlspecialchars($sanpham[$i]['TenSP']),
            htmlspecialchars($sanpham[$i]['Loai']),
            htmlspecialchars($sanpham[$i]['ThuongHieu']),
            htmlspecialchars($sanpham[$i]['MoTa']),
            htmlspecialchars($sanpham[$i]['MaSP']),
            htmlspecialchars($sanpham[$i]['GiaBan']),
            htmlspecialchars($sanpham[$i]['SoLuong'])];
        $sql = "SELECT STT FROM sanpham where MaSP='" . $sanpham[$i]['MaSP'] . "'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $anh = htmlspecialchars($row['STT']);
        $Hinh = 'image_' . $anh . '.png';
        echo '  <a href="../ct/index.php?MaSP='.$MaSP.'">
        <div class="tooltip">
            <img src="../anh/'. $Hinh . '" alt="">
            <h4>' . $Gia . ' VNĐ</h4>
            <span class="text">
                <br>Tên Máy:' . $Ten . '<br>Loại: ' . $Loai . '<br>Hãng:' . $TH . '<br>Mô tả: ' . $MT . '<br>Giá:' . $Gia . '<br>Còn lại: ' . $SL . '
            </span>
        </div>';
        }
    }
        }
        else{
          echo '<p>Không tìm thấy sản phẩm phù hợp</p>';
        }
        
        ?>
    <div class="footer">
    <div class="footer-content">
      <div class="footer-section">
        <h3>Về TQS Store</h3>
        <p>Chuyên cung cấp các sản phẩm công nghệ chính hãng, chất lượng với giá cả hợp lý.</p>
        <p><i class="fas fa-map-marker-alt"></i> 195 Nguyễn Chí Thanh huyện Dương Minh Châu, Tây Ninh</p>
        <p><i class="fas fa-phone"></i> 0395898212</p>
        <p><i class="fas fa-envelope"></i> 0306241144@caothang.edu.vn</p>
      </div>

      <div class="footer-section">
        <h3>Liên kết nhanh</h3>
        <p><a href="index.php">Trang chủ</a></p>
        <p><a href="#">Sản phẩm</a></p>
        <p><a href="#">Khuyến mãi</a></p>
        <p><a href="#">Tin tức</a></p>
        <p><a href="#">Liên hệ</a></p>
      </div>

      <div class="footer-section">
        <h3>Hỗ trợ khách hàng</h3>
        <p><a href="#">Hướng dẫn mua hàng</a></p>
        <p><a href="#">Chính sách bảo hành</a></p>
        <p><a href="#">Chính sách đổi trả</a></p>
        <p><a href="#">Câu hỏi thường gặp</a></p>
      </div>

      <div class="footer-section">
        <h3>Theo dõi chúng tôi</h3>
        <p>Đăng ký nhận tin khuyến mãi</p>
        <form action="https://formspree.io/f/mblqlzpw" method="POST">
  <input type="email" name="email" placeholder="Email của bạn" required
    style="padding: 0.5rem; width: 100%; border: none; border-radius: 4px; margin-bottom: 1rem;">
  <button type="submit" class="btn btn-primary" style="width: 100%;">Đăng ký</button>
</form>
<p id="form-msg" style="font-size: 14px; color: lightgreen; display:none;">Cảm ơn bạn đã đăng ký!</p>

<script>
  const form = document.querySelector('form[action*="formspree"]');
  const msg = document.getElementById('form-msg');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const res = await fetch(form.action, { method: 'POST', body: data });
    if (res.ok) {
      msg.style.display = 'block';
      form.reset();
    } else {
      msg.textContent = 'Xin lỗi, có lỗi xảy ra. Vui lòng thử lại!';
      msg.style.color = 'red';
      msg.style.display = 'block';
    }
  });
</script>


        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <p>&copy; 2023 TQS Store. Tất cả các quyền được bảo lưu.</p>
    </div>
  </div>
    </body>
    </html>