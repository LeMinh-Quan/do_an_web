function login(){
    window.location.href = "../login/user.php";
}
